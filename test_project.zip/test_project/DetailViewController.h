//
//  DetailViewController.h
//  test_project
//
//  Created by Tabraiz on 12/20/19.
//  Copyright © 2019 test_project. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

{
    
}
@property (weak, nonatomic) IBOutlet UILabel *title_name_lbl;


@property (weak, nonatomic) IBOutlet UILabel *price_lbl;


@property (weak, nonatomic) IBOutlet UILabel *date_created_lbl;

@property (weak, nonatomic) IBOutlet UILabel *image_id_lbl;

@property (weak, nonatomic) IBOutlet UILabel *image_uid_lbl;

@property (weak, nonatomic) IBOutlet UIImageView *main_ImageView;

@property (weak, nonatomic) NSString * image_name;
@property (weak, nonatomic) NSString * image_url;
@property (weak, nonatomic) NSString * image_id;
@property (weak, nonatomic) NSString * image_uid;
@property (weak, nonatomic) NSString * image_price;
@property (weak, nonatomic) NSString * image_date;


@end
     
