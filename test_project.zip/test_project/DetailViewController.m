//
//  DetailViewController.m
//  test_project
//
//  Created by Tabraiz on 12/20/19.
//  Copyright © 2019 test_project. All rights reserved.
//

#import "DetailViewController.h"



@interface DetailViewController ()


@end

@implementation DetailViewController

@synthesize image_id,image_uid,image_url,image_date,image_name,image_price;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
}

-(void)viewWillAppear:(BOOL)animated
{

    _title_name_lbl.text = [NSString stringWithFormat:@"NAME: %@,",image_name];
    
    _price_lbl.text = [NSString stringWithFormat:@"PRICE: %@,",image_price];
    
    _date_created_lbl.text = [NSString stringWithFormat:@"DATE: %@,",image_date];;
    
    _image_id_lbl.text = [NSString stringWithFormat:@"ID: %@,",image_id];;
    
    _image_uid_lbl.text = [NSString stringWithFormat:@"UID: %@,",image_uid]; ;
        
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
