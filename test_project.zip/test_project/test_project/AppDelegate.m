//
//  AppDelegate.m
//  test_project
//
//  Created by Tabraiz on 12/19/19.
//  Copyright © 2019 test_project. All rights reserved.
//

#import "AppDelegate.h"

NSMutableArray * Result_Arr;
NSMutableDictionary * Main_Dictionary;
NSMutableArray * Main_Arr;


NSMutableDictionary * subDictionary;
NSMutableArray * subArray;


@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    Result_Arr = [[NSMutableArray alloc]init];
    Main_Dictionary = [[NSMutableDictionary alloc]init];
    Main_Arr = [[NSMutableArray alloc]init];

    
    subDictionary = [[NSMutableDictionary alloc]init];
    subArray = [[NSMutableArray alloc]init];

    
        NSString *dataUrl = @"https://ey3f2y0nre.execute-api.us-east-1.amazonaws.com/default/dynamodb-writer";
        NSURL *url = [NSURL URLWithString:dataUrl];
        
        // 2
        NSURLSessionDataTask *downloadTask = [[NSURLSession sharedSession]
                                              dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                                                  // 4: Handle response here
                                                  
                                                  Main_Arr = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
                                                  
                                                  
                                                  Result_Arr = [Main_Arr valueForKey:@"results"];
                                                  
                                                  
                                                  for(int a=0; a< Result_Arr.count; a++)
                                                  {
                                                      NSDictionary * diction = [Result_Arr objectAtIndex:a];
                                                      
                                                      [Main_Dictionary setObject:diction forKey:[NSString stringWithFormat:@"%d",a]];
                                                  }
                                                  

                                                  
                                                  NSUserDefaults * def = [NSUserDefaults standardUserDefaults];
                                                  [def setObject:Main_Dictionary forKey:@"data"];
                                                  [def synchronize];
                                                  

                                                  
                                                  
                                                  
                                              }];
        
        // 3
        [downloadTask resume];
        
    

    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
